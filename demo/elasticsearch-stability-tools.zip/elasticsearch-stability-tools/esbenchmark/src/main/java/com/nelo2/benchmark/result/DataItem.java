package com.nelo2.benchmark.result;

public class DataItem {

}
