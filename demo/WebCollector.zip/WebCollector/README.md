# WebCollector
WebCollector is an open source web crawler framework based on Java.It provides some simple interfaces for crawling the Web page.
