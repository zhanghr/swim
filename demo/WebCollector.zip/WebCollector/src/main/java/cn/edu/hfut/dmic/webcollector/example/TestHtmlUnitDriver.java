package cn.edu.hfut.dmic.webcollector.example;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class TestHtmlUnitDriver {
  
	public static void main(String[] args) {
		//http://www.cnblogs.com/qingchunjun/p/4208159.html selenium定位页面的几种方式
     //   testBaidu();
        testTiantuan();

	}

	private static void testTiantuan() {
		WebDriver driver=new HtmlUnitDriver(); 
		 driver.get("http://tuan.zhiuxing.com:9999/");  
		 System.out.println("页面标题："+driver.getTitle());  
		
		 List<WebElement> as = driver.findElements(By.tagName("a"));
		 System.out.println("页面a标签的个数："+as.size());
		 System.out.println("=====================================================");
		 for(WebElement divInfo:as){
			  String text = divInfo.getText();
			  if(StringUtils.isNoneBlank(text)){
				  String url = divInfo.getAttribute("href");
				  if(url!=null && url.contains("tuan.zhiuxing.com:9999")){
					  System.out.println(text);
					  System.out.println(url);
				  }
				  
				  
				 
				  
			  }
	           
	        }
		 System.out.println("=====================================================");
		 
		/* List<WebElement> buttons = driver.findElements(By.tagName("button"));
		 System.out.println("页面按钮的个数："+buttons.size());*/
		
	}

	private static void testBaidu() {
		WebDriver driver=new HtmlUnitDriver();  
        //打开百度首页  
        driver.get("http://www.baidu.com/");  
        //打印页面标题  
        System.out.println("页面标题："+driver.getTitle());  
        //根据id获取页面元素输入框  
        WebElement search=driver.findElement(By.id("kw"));  
        //在id=“kw”的输入框输入“selenium”  
        search.sendKeys("selenium");  
        //根据id获取提交按钮  
        WebElement submit=driver.findElement(By.id("su"));  
        //点击按钮查询  
        submit.click();  
        //打印当前页面标题  
        System.out.println("页面标题："+driver.getTitle());  
        //返回当前页面的url  
        System.out.println("页面url："+driver.getCurrentUrl());  
        //返回当前的浏览器的窗口句柄  
        System.out.println("窗口句柄："+driver.getWindowHandle()); 
		
	}
	
	

}
