package cn.edu.hfut.dmic.webcollector.example;

import java.net.URLEncoder;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import com.gargoylesoftware.htmlunit.BrowserVersion;

import cn.edu.hfut.dmic.webcollector.crawler.DeepCrawler;
import cn.edu.hfut.dmic.webcollector.example.util.PageUtils;
import cn.edu.hfut.dmic.webcollector.model.Links;
import cn.edu.hfut.dmic.webcollector.model.Page;

public class TiantuanCrawler  extends DeepCrawler {

	@Override
	public Links visitAndGetNextLinks(Page page) {
		 /*HtmlUnitDriver可以抽取JS生成的数据*/
	        HtmlUnitDriver driver=PageUtils.getDriver(page,BrowserVersion.CHROME);
	        
	        System.out.println("页面标题："+driver.getTitle());  
	        /*HtmlUnitDriver也可以像Jsoup一样用CSS SELECTOR抽取数据
	          关于HtmlUnitDriver的文档请查阅selenium相关文档*/
	        List<WebElement> divInfos=driver.findElementsByCssSelector("h3>a[id^=uigs]");
	        for(WebElement divInfo:divInfos){
//	            System.out.println(divInfo.getText());
	        }
	        return null;
	}
	
	public TiantuanCrawler(String crawlPath) {
		super(crawlPath);
	}

	public static void main(String[] args) {
		 DemoJSCrawler crawler=new DemoJSCrawler("J:\\html");
		  crawler.addSeed("http://tuan.zhiuxing.com:9999/");
		  try {
			crawler.start(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	

}
