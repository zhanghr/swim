package cn.edu.hfut.dmic.webcollector.example;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class TiantuanCrawler  {

	

	public static void main(String[] args) {
		
		  
		  String  uri="http://tuan.zhiuxing.com:9999/?mod=subscribe&code=mail";
		  
		  WebClient webClient = new WebClient();
		  try {
			 URL url=new URL(uri);
			    webClient.getOptions().setJavaScriptEnabled(true);  
			    webClient.getOptions().setActiveXNative(false);  
		        webClient.getOptions().setCssEnabled(false);  
		        webClient.getOptions().setThrowExceptionOnScriptError(false);  
		        webClient.waitForBackgroundJavaScript(600*1000);  
		        webClient.setAjaxController(new NicelyResynchronizingAjaxController());  
		         HtmlPage page = webClient.getPage(url);
		         webClient.waitForBackgroundJavaScript(1000*3);  
		         webClient.setJavaScriptTimeout(0);  
		         
		         
		         System.out.println(page.asText());
			
		  } catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FailingHttpStatusCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
